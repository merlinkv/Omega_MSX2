# omega_mainboard1.4eu
This is a variant from the OMEGA HOME COMPUTER mainboard pcb 1.4us.
Is based on the last design for the mainboard pcb (version 1.4us). You can find it at https://github.com/skiselev/omega
Please, refer to it for full documentation or you can also go to https://msxmakers.design.blog/proyectos/omega-home-computer/

## changes
The only changes from mainboard version 1.4us are:

a) Din-8 connectors used are more common on EU than in 1.4us version.

b) the jumpers for selecting the mapper changes are not connected so a cutout of the traces is not needed.
